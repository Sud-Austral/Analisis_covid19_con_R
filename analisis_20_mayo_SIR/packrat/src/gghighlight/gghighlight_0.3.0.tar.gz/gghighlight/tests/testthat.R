library(testthat)
library(gghighlight)

test_check("gghighlight")
